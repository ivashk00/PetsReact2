import React from "react";
const Footer = () => {
    return (
        <div>
            <footer class="border-bottom bg-success">
                <p class="text-white p-3">GET PET BACK © Copyright, 2022</p>
                <p class="text-white p-3">Все права защищены</p>
            </footer>
        </div>
    )
};
export default Footer;